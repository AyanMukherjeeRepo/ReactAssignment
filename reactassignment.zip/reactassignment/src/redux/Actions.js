import { showusers, login } from "./Actiontypes";
export const showuser = (payload) => {
  return {
    type: showusers,
    payload: payload,
  };
};
export const loginuser = () => {
  return {
    type: login,
  };
};
