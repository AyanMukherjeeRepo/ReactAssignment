import React, { useState } from "react";
import { useSelector } from "react-redux";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";
import { withStyles } from "@material-ui/core/styles";
import styles from "../Users/Users.module.css";
const StyledTableCell = withStyles((theme) => ({
  head: {
    backgroundColor: theme.palette.common.black,
    color: theme.palette.common.white,
  },
  body: {
    fontSize: 14,
  },
}))(TableCell);
const StyledTableRow = withStyles((theme) => ({
  root: {
    "&:nth-of-type(odd)": {
      backgroundColor: theme.palette.action.hover,
    },
  },
}))(TableRow);

function Users() {
  const userdetails = useSelector((state) => state.userdetails);
  return (
    <div className={styles.userscontainer}>
      <div className={styles.users}>
        <h2 className={styles.header}>Dashboard</h2>
        {
          <TableContainer component={Paper}>
            <Table aria-label="customized table">
              <TableHead>
                <TableRow>
                  {Object.keys(userdetails[0]).reduce((result, item, index) => {
                    if (item !== "id") {
                      result.push(
                        <StyledTableCell key={result.length}>
                          {item}
                        </StyledTableCell>
                      );
                    }
                    return result;
                  }, [])}
                </TableRow>
              </TableHead>
              <TableBody>
                {userdetails.map((row) => (
                  <StyledTableRow key={row.id}>
                    <StyledTableCell component="th" scope="row">
                      {row.name}
                    </StyledTableCell>
                    <StyledTableCell>{row.age}</StyledTableCell>
                    <StyledTableCell>{row.gender}</StyledTableCell>
                    <StyledTableCell>{row.email}</StyledTableCell>
                    <StyledTableCell>{row.phoneNo}</StyledTableCell>
                  </StyledTableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        }
      </div>
    </div>
  );
}

export default Users;
