import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { useHistory } from "react-router-dom";
import style from "../Login/Login.module.css";
import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";
import Snackbar from "@material-ui/core/Snackbar";
import MuiAlert from "@material-ui/lab/Alert";
import { loginuser } from "../../redux/Actions";
function Alert(props) {
  return <MuiAlert elevation={6} variant="filled" {...props} />;
}
function Login() {
  const history = useHistory();
  const dispatch = useDispatch();
  const [username, setusername] = useState("");
  const [password, setpassword] = useState("");
  const [error, seterror] = useState(false);
  const authenticateduser = {
    username: "hruday@gmail.com",
    password: "hruday123",
  };

  function Loginhandler() {
    console.log(history);
    if (
      authenticateduser.username === username &&
      authenticateduser.password === password
    ) {
      dispatch(loginuser());
      history.push("/users");
    } else {
      seterror(true);
    }
  }
  const handleClose = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }

    seterror(false);
  };
  return (
    <div className={style.logincontainer}>
      <div className={style.login}>
        <TextField
          id="outlined-basic"
          label="UserName"
          variant="outlined"
          value={username}
          onChange={(e) => setusername(e.target.value)}
        />
        <TextField
          type="password"
          id="outlined-basic"
          label="Password"
          variant="outlined"
          value={password}
          onChange={(e) => setpassword(e.target.value)}
        />
        <Button variant="contained" color="primary" onClick={Loginhandler}>
          Login
        </Button>
        <Snackbar open={error} autoHideDuration={3000} onClose={handleClose}>
          <Alert severity="error">Unauthorized User</Alert>
        </Snackbar>
      </div>
    </div>
  );
}

export default Login;
