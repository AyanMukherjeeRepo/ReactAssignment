import "./App.css";
import { useSelector } from "react-redux";
import Login from "./components/Login/Login";
import {
  BrowserRouter as Router,
  Redirect,
  Route,
  Switch,
} from "react-router-dom";
import Users from "./components/Users/Users";
function App() {
  const loggedIn = useSelector((state) => state.loggedIn);
  return (
    <Router>
      <div className="App">
        <Switch>
          <Route exact path="/" component={Login} />
          <Route
            exact
            path="/users"
            render={() => (loggedIn ? <Users /> : <Redirect to="/" />)}
          />
        </Switch>
      </div>
    </Router>
  );
}

export default App;
