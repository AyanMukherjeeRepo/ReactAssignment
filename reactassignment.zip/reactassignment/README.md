To Run this project run 'npm install' in root directory
